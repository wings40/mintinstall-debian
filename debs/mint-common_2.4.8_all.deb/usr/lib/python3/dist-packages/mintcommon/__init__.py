
"""Collection of classes shared by Mint packages."""

__all__ = ["installer", "apt_changelog", "additionalfiles"]
